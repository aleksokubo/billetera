import { PrismaClient } from '@prisma/client'
import bcrypt from 'bcryptjs'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Create admin user
  const adminEmail = 'admin@global66.com'
  const adminPassword = 'Admin123!'

  const existingAdmin = await prisma.user.findUnique({
    where: { email: adminEmail },
  })

  if (!existingAdmin) {
    const hashedPassword = await bcrypt.hash(adminPassword, 12)

    const admin = await prisma.user.create({
      data: {
        email: adminEmail,
        password: hashedPassword,
        name: 'Admin User',
        firstName: 'Admin',
        lastName: 'User',
        role: 'ADMIN',
        kycStatus: 'VERIFIED',
        wallet: {
          create: {
            balance: 0,
          },
        },
      },
    })

    console.log('✅ Admin user created:', admin.email)
  } else {
    console.log('ℹ️  Admin user already exists')
  }

  // Create default exchange rates
  const defaultRates = [
    { currency: 'ARS', rate: 1000, source: 'manual' },
    { currency: 'EUR', rate: 0.92, source: 'manual' },
    { currency: 'GBP', rate: 0.79, source: 'manual' },
    { currency: 'CLP', rate: 950, source: 'manual' },
    { currency: 'PEN', rate: 3.75, source: 'manual' },
  ]

  for (const rate of defaultRates) {
    await prisma.exchangeRate.upsert({
      where: { currency: rate.currency },
      update: {},
      create: rate,
    })
  }

  console.log('✅ Exchange rates seeded')

  // Create default admin settings
  const existingSettings = await prisma.adminSettings.findFirst()
  if (!existingSettings) {
    await prisma.adminSettings.create({
      data: { feePercent: 0.5 },
    })
    console.log('✅ Admin settings created')
  } else {
    console.log('ℹ️  Admin settings already exist')
  }

  // Create a test user
  const testEmail = 'user@global66.com'
  const existingUser = await prisma.user.findUnique({ where: { email: testEmail } })

  if (!existingUser) {
    const hashedPassword = await bcrypt.hash('User123!', 12)
    await prisma.user.create({
      data: {
        email: testEmail,
        password: hashedPassword,
        name: 'Test User',
        firstName: 'Test',
        lastName: 'User',
        role: 'USER',
        kycStatus: 'PENDING',
        wallet: {
          create: {
            balance: 1000,
          },
        },
      },
    })
    console.log('✅ Test user created:', testEmail)
  }

  console.log('\n✅ Database seeded successfully!')
  console.log('\nCredentials:')
  console.log('  Admin: admin@global66.com / Admin123!')
  console.log('  User:  user@global66.com / User123!')
}

main()
  .catch((e) => {
    console.error('❌ Seed error:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })

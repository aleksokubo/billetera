'use client'

import { useSession } from 'next-auth/react'
import { Bell } from 'lucide-react'

interface HeaderProps {
  title: string
  subtitle?: string
}

export function Header({ title, subtitle }: HeaderProps) {
  const { data: session } = useSession()

  return (
    <header
      className="flex items-center justify-between px-6 py-4"
      style={{
        borderBottom: '1px solid rgba(255,255,255,0.07)',
        background: 'rgba(255,255,255,0.02)',
      }}
    >
      <div>
        <h1 className="text-xl font-bold text-white">{title}</h1>
        {subtitle && <p className="text-sm text-gray-400 mt-0.5">{subtitle}</p>}
      </div>
      <div className="flex items-center gap-4">
        <button
          className="relative w-9 h-9 rounded-xl flex items-center justify-center transition-colors"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          <Bell className="w-4 h-4 text-gray-400" />
        </button>
        <div
          className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold overflow-hidden"
          style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
        >
          {session?.user?.image ? (
            <img src={session.user.image} alt="" className="w-full h-full object-cover" />
          ) : (
            session?.user?.name?.charAt(0)?.toUpperCase() || 'U'
          )}
        </div>
      </div>
    </header>
  )
}

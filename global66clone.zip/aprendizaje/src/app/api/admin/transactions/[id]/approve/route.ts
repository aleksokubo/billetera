import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { adminNote } = await req.json().catch(() => ({ adminNote: '' }))
    const { id } = params

    const transaction = await prisma.transaction.findUnique({
      where: { id },
      include: { user: { include: { wallet: true } } },
    })

    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    if (transaction.status === 'APPROVED') {
      return NextResponse.json({ error: 'Transaction already approved' }, { status: 400 })
    }

    // Update transaction status
    const updated = await prisma.transaction.update({
      where: { id },
      data: {
        status: 'APPROVED',
        adminNote: adminNote || null,
      },
    })

    // If LOAD transaction: add to wallet balance
    if (transaction.type === 'LOAD') {
      const netAmount = transaction.amountUSD - transaction.fee

      await prisma.wallet.upsert({
        where: { userId: transaction.userId },
        update: { balance: { increment: netAmount } },
        create: { userId: transaction.userId, balance: netAmount },
      })
    }

    // If TRANSFER_APP: deduct from sender, add to recipient
    if (transaction.type === 'TRANSFER_APP' && transaction.recipientEmail) {
      const totalDeducted = transaction.amountUSD + transaction.fee

      // Deduct from sender
      await prisma.wallet.update({
        where: { userId: transaction.userId },
        data: { balance: { decrement: totalDeducted } },
      })

      // Add to recipient
      const recipient = await prisma.user.findUnique({
        where: { email: transaction.recipientEmail },
        include: { wallet: true },
      })

      if (recipient) {
        await prisma.wallet.upsert({
          where: { userId: recipient.id },
          update: { balance: { increment: transaction.amountUSD } },
          create: { userId: recipient.id, balance: transaction.amountUSD },
        })
      }
    }

    // If bank transfers: deduct from sender
    if (['TRANSFER_ACH', 'TRANSFER_SEPA', 'TRANSFER_BANK'].includes(transaction.type)) {
      const totalDeducted = transaction.amountUSD + transaction.fee

      await prisma.wallet.update({
        where: { userId: transaction.userId },
        data: { balance: { decrement: totalDeducted } },
      })
    }

    return NextResponse.json({ message: 'Transaction approved', transaction: updated })
  } catch (error) {
    console.error('Approve error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

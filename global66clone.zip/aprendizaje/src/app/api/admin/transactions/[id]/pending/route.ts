import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { adminNote } = await req.json().catch(() => ({ adminNote: '' }))
    const { id } = params

    const transaction = await prisma.transaction.findUnique({
      where: { id },
    })

    if (!transaction) {
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    const updated = await prisma.transaction.update({
      where: { id },
      data: {
        status: 'PENDING',
        adminNote: adminNote || null,
      },
    })

    return NextResponse.json({ message: 'Transaction set to pending', transaction: updated })
  } catch (error) {
    console.error('Pending error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

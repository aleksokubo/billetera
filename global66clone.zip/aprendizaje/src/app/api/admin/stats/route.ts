export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const [
      totalUsers,
      pendingTransactions,
      approvedTransactions,
      rejectedTransactions,
      allTransactions,
      todayTransactions,
      recentTransactions,
    ] = await Promise.all([
      prisma.user.count(),
      prisma.transaction.count({ where: { status: 'PENDING' } }),
      prisma.transaction.count({ where: { status: 'APPROVED' } }),
      prisma.transaction.count({ where: { status: 'REJECTED' } }),
      prisma.transaction.findMany({
        where: { status: 'APPROVED' },
        select: { amountUSD: true },
      }),
      prisma.transaction.findMany({
        where: { status: 'APPROVED', createdAt: { gte: today } },
        select: { amountUSD: true },
      }),
      prisma.transaction.findMany({
        take: 5,
        orderBy: { createdAt: 'desc' },
        include: { user: { select: { email: true, name: true } } },
      }),
    ])

    const totalVolume = allTransactions.reduce((sum, tx) => sum + tx.amountUSD, 0)
    const todayVolume = todayTransactions.reduce((sum, tx) => sum + tx.amountUSD, 0)

    return NextResponse.json({
      totalUsers,
      pendingTransactions,
      approvedTransactions,
      rejectedTransactions,
      totalVolume,
      todayVolume,
      recentTransactions,
    })
  } catch (error) {
    console.error('Admin stats error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { updateExchangeRatesInDB } from '@/lib/exchange-rates'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Trigger a fresh fetch from the API
    await updateExchangeRatesInDB()

    const rates = await prisma.exchangeRate.findMany()
    return NextResponse.json({ message: 'Rates refreshed', rates })
  } catch (error) {
    console.error('Admin rates refresh error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { currency, rate } = await req.json()

    if (!currency || !rate || rate <= 0) {
      return NextResponse.json({ error: 'Valid currency and rate are required' }, { status: 400 })
    }

    const updated = await prisma.exchangeRate.upsert({
      where: { currency },
      update: {
        rate,
        source: 'manual',
        updatedAt: new Date(),
      },
      create: {
        currency,
        rate,
        source: 'manual',
      },
    })

    return NextResponse.json({ rate: updated })
  } catch (error) {
    console.error('Admin rates PUT error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

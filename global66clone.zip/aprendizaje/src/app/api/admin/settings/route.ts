export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    let settings = await prisma.adminSettings.findFirst()

    if (!settings) {
      settings = await prisma.adminSettings.create({
        data: { feePercent: 0.5 },
      })
    }

    return NextResponse.json({ settings })
  } catch (error) {
    console.error('Admin settings GET error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id || session.user.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { feePercent } = await req.json()

    if (feePercent === undefined || feePercent < 0 || feePercent > 10) {
      return NextResponse.json({ error: 'Invalid fee percentage (0-10%)' }, { status: 400 })
    }

    let settings = await prisma.adminSettings.findFirst()

    if (settings) {
      settings = await prisma.adminSettings.update({
        where: { id: settings.id },
        data: { feePercent },
      })
    } else {
      settings = await prisma.adminSettings.create({
        data: { feePercent },
      })
    }

    return NextResponse.json({ settings })
  } catch (error) {
    console.error('Admin settings PUT error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

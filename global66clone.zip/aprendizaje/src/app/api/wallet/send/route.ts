export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { recipientEmail, amount, description } = await req.json()

    if (!recipientEmail || !amount || amount <= 0) {
      return NextResponse.json(
        { error: 'Valid recipient email and amount are required' },
        { status: 400 }
      )
    }

    if (recipientEmail === session.user.email) {
      return NextResponse.json(
        { error: 'Cannot send money to yourself' },
        { status: 400 }
      )
    }

    // Check recipient exists
    const recipient = await prisma.user.findUnique({
      where: { email: recipientEmail },
      include: { wallet: true },
    })

    if (!recipient) {
      return NextResponse.json(
        { error: 'Recipient not found' },
        { status: 404 }
      )
    }

    // Check sender balance
    const senderWallet = await prisma.wallet.findUnique({
      where: { userId: session.user.id },
    })

    if (!senderWallet || senderWallet.balance < amount) {
      return NextResponse.json(
        { error: 'Insufficient balance' },
        { status: 400 }
      )
    }

    // Get fee settings
    const settings = await prisma.adminSettings.findFirst()
    const feePercent = settings?.feePercent ?? 0.5
    const fee = (amount * feePercent) / 100
    const totalDeducted = amount + fee

    if (senderWallet.balance < totalDeducted) {
      return NextResponse.json(
        { error: 'Insufficient balance including fees' },
        { status: 400 }
      )
    }

    // Create transaction (PENDING - needs admin approval)
    const transaction = await prisma.transaction.create({
      data: {
        userId: session.user.id,
        type: 'TRANSFER_APP',
        amount,
        currency: 'USD',
        amountUSD: amount,
        exchangeRate: 1,
        fee,
        status: 'PENDING',
        recipientEmail,
        description: description || `Transfer to ${recipientEmail}`,
      },
    })

    return NextResponse.json({
      message: 'Transfer request submitted for review',
      transaction,
    })
  } catch (error) {
    console.error('Send error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

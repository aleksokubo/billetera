export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const {
      type,
      amount,
      description,
      bankName,
      accountNumber,
      routingNumber,
      ibanNumber,
      swiftCode,
    } = await req.json()

    if (!amount || amount <= 0) {
      return NextResponse.json({ error: 'Valid amount is required' }, { status: 400 })
    }

    const validTypes = ['TRANSFER_ACH', 'TRANSFER_SEPA', 'TRANSFER_BANK']
    if (!validTypes.includes(type)) {
      return NextResponse.json({ error: 'Invalid transfer type' }, { status: 400 })
    }

    // Get sender wallet
    const wallet = await prisma.wallet.findUnique({
      where: { userId: session.user.id },
    })

    if (!wallet || wallet.balance < amount) {
      return NextResponse.json({ error: 'Insufficient balance' }, { status: 400 })
    }

    // Get fee settings (bank transfers use 1%)
    const settings = await prisma.adminSettings.findFirst()
    const feePercent = (settings?.feePercent ?? 0.5) * 2 // Double fee for bank transfers
    const fee = (amount * feePercent) / 100
    const totalDeducted = amount + fee

    if (wallet.balance < totalDeducted) {
      return NextResponse.json({ error: 'Insufficient balance including fees' }, { status: 400 })
    }

    // Create transaction
    const transaction = await prisma.transaction.create({
      data: {
        userId: session.user.id,
        type,
        amount,
        currency: 'USD',
        amountUSD: amount,
        exchangeRate: 1,
        fee,
        status: 'PENDING',
        description: description || `${type.replace('TRANSFER_', '')} Transfer`,
        bankName,
        accountNumber,
        routingNumber,
        ibanNumber,
        swiftCode,
      },
    })

    return NextResponse.json({
      message: 'Transfer request submitted for review',
      transaction,
    })
  } catch (error) {
    console.error('Transfer error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { convertToUSD } from '@/lib/exchange-rates'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { amount, currency } = await req.json()

    if (!amount || !currency || amount <= 0) {
      return NextResponse.json(
        { error: 'Valid amount and currency are required' },
        { status: 400 }
      )
    }

    const supportedCurrencies = ['ARS', 'EUR', 'GBP', 'CLP', 'PEN', 'USD']
    if (!supportedCurrencies.includes(currency)) {
      return NextResponse.json(
        { error: 'Unsupported currency' },
        { status: 400 }
      )
    }

    // Get exchange rate
    let exchangeRate = 1
    if (currency !== 'USD') {
      const rateRecord = await prisma.exchangeRate.findUnique({
        where: { currency },
      })
      if (!rateRecord) {
        return NextResponse.json(
          { error: 'Exchange rate not available for this currency' },
          { status: 400 }
        )
      }
      exchangeRate = rateRecord.rate
    }

    // Get fee settings
    const settings = await prisma.adminSettings.findFirst()
    const feePercent = settings?.feePercent ?? 0.5
    const amountUSD = convertToUSD(amount, currency, exchangeRate)
    const fee = (amountUSD * feePercent) / 100

    // Create transaction (PENDING - needs admin approval)
    const transaction = await prisma.transaction.create({
      data: {
        userId: session.user.id,
        type: 'LOAD',
        amount,
        currency,
        amountUSD,
        exchangeRate,
        fee,
        status: 'PENDING',
        description: `Load balance: ${amount} ${currency}`,
      },
    })

    return NextResponse.json({
      message: 'Load request submitted for review',
      transaction,
      amountUSD,
      fee,
    })
  } catch (error) {
    console.error('Load error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { updateExchangeRatesInDB } from '@/lib/exchange-rates'

let lastFetch = 0
const FETCH_INTERVAL = 5 * 60 * 1000 // 5 minutes

export async function GET(req: NextRequest) {
  try {
    const now = Date.now()

    // Auto-refresh rates every 5 minutes
    if (now - lastFetch > FETCH_INTERVAL) {
      await updateExchangeRatesInDB()
      lastFetch = now
    }

    const rates = await prisma.exchangeRate.findMany({
      orderBy: { currency: 'asc' },
    })

    return NextResponse.json({ rates })
  } catch (error) {
    console.error('Exchange rates error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

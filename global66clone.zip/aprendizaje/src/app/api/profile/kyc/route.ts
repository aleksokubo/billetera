export const dynamic = 'force-dynamic'

import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { document } = await req.json()

    if (!document) {
      return NextResponse.json({ error: 'Document is required' }, { status: 400 })
    }

    await prisma.user.update({
      where: { id: session.user.id },
      data: {
        kycDocument: document,
        kycStatus: 'PENDING',
      },
    })

    return NextResponse.json({ message: 'KYC document submitted for review' })
  } catch (error) {
    console.error('KYC error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

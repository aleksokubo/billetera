'use client'

import { useEffect, useState } from 'react'
import { Header } from '@/components/layout/Header'
import { Users, Shield, CheckCircle, Clock, XCircle } from 'lucide-react'
import { formatDate } from '@/lib/utils'

interface UserData {
  id: string
  email: string
  name: string | null
  firstName: string | null
  lastName: string | null
  role: string
  kycStatus: string
  createdAt: string
  wallet: { balance: number } | null
  _count: { transactions: number }
}

const KYC_STYLES = {
  PENDING: { color: '#fbbf24', bg: 'rgba(245,158,11,0.1)', border: 'rgba(245,158,11,0.2)' },
  VERIFIED: { color: '#34d399', bg: 'rgba(16,185,129,0.1)', border: 'rgba(16,185,129,0.2)' },
  REJECTED: { color: '#f87171', bg: 'rgba(239,68,68,0.1)', border: 'rgba(239,68,68,0.2)' },
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<UserData[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    fetch('/api/admin/users')
      .then((r) => r.json())
      .then((d) => {
        setUsers(d.users || [])
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const filtered = users.filter((u) =>
    search
      ? u.email.toLowerCase().includes(search.toLowerCase()) ||
        (u.name || '').toLowerCase().includes(search.toLowerCase())
      : true
  )

  const getKycIcon = (status: string) => {
    switch (status) {
      case 'VERIFIED': return <CheckCircle className="w-3.5 h-3.5" />
      case 'REJECTED': return <XCircle className="w-3.5 h-3.5" />
      default: return <Clock className="w-3.5 h-3.5" />
    }
  }

  return (
    <div className="p-6 space-y-6">
      <Header title="Users" subtitle="All registered users on the platform" />

      {/* Search */}
      <div
        className="rounded-2xl p-4"
        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by email or name..."
          className="w-full px-4 py-2.5 rounded-xl text-white placeholder-gray-600 outline-none text-sm"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        />
      </div>

      {/* Users table */}
      <div
        className="rounded-2xl overflow-hidden"
        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        <div className="p-5 pb-4 flex items-center gap-2">
          <Users className="w-4 h-4 text-indigo-400" />
          <h3 className="font-semibold text-white">{filtered.length} users</h3>
        </div>

        {loading ? (
          <div className="px-5 pb-5 space-y-3">
            {[...Array(5)].map((_, i) => <div key={i} className="h-16 rounded-xl shimmer" />)}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">User</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">Role</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">KYC</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">Balance</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">Transactions</th>
                  <th className="text-left px-5 py-3 text-xs text-gray-500 font-medium">Joined</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((user) => {
                  const kycStyle = KYC_STYLES[user.kycStatus as keyof typeof KYC_STYLES] || KYC_STYLES.PENDING
                  return (
                    <tr
                      key={user.id}
                      className="transition-colors"
                      style={{ borderBottom: '1px solid rgba(255,255,255,0.04)' }}
                    >
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold shrink-0"
                            style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
                          >
                            {user.name?.charAt(0)?.toUpperCase() || user.email.charAt(0).toUpperCase()}
                          </div>
                          <div>
                            <p className="text-white font-medium">{user.name || '—'}</p>
                            <p className="text-xs text-gray-500">{user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
                          style={{
                            background: user.role === 'ADMIN' ? 'rgba(99,102,241,0.1)' : 'rgba(255,255,255,0.06)',
                            color: user.role === 'ADMIN' ? '#a5b4fc' : 'rgba(255,255,255,0.5)',
                          }}
                        >
                          {user.role === 'ADMIN' && <Shield className="w-3 h-3" />}
                          {user.role}
                        </span>
                      </td>
                      <td className="px-5 py-3.5">
                        <span
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
                          style={{ background: kycStyle.bg, border: `1px solid ${kycStyle.border}`, color: kycStyle.color }}
                        >
                          {getKycIcon(user.kycStatus)}
                          {user.kycStatus}
                        </span>
                      </td>
                      <td className="px-5 py-3.5 text-white font-medium">
                        ${user.wallet?.balance?.toFixed(2) ?? '0.00'}
                      </td>
                      <td className="px-5 py-3.5 text-gray-400">
                        {user._count.transactions}
                      </td>
                      <td className="px-5 py-3.5 text-gray-500 text-xs">
                        {formatDate(user.createdAt)}
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
            {filtered.length === 0 && (
              <div className="p-10 text-center text-gray-500">No users found</div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

'use client'

import { useEffect, useState } from 'react'
import { Header } from '@/components/layout/Header'
import { CheckCircle, XCircle, Clock, Filter, Loader2, ChevronDown, ChevronUp } from 'lucide-react'
import { formatCurrency, formatDate, TRANSACTION_TYPE_LABELS } from '@/lib/utils'

interface Transaction {
  id: string
  type: string
  amount: number
  currency: string
  amountUSD: number
  fee: number
  status: string
  description: string | null
  recipientEmail: string | null
  bankName: string | null
  accountNumber: string | null
  routingNumber: string | null
  ibanNumber: string | null
  swiftCode: string | null
  adminNote: string | null
  createdAt: string
  user: { email: string; name: string | null }
}

export default function AdminTransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [noteMap, setNoteMap] = useState<Record<string, string>>({})

  useEffect(() => {
    fetchTransactions()
  }, [])

  const fetchTransactions = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/transactions')
      const data = await res.json()
      setTransactions(data.transactions || [])
    } finally {
      setLoading(false)
    }
  }

  const handleAction = async (id: string, action: 'approve' | 'reject' | 'pending') => {
    setActionLoading(`${id}-${action}`)
    try {
      const res = await fetch(`/api/admin/transactions/${id}/${action}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ adminNote: noteMap[id] || '' }),
      })
      if (res.ok) {
        await fetchTransactions()
      }
    } finally {
      setActionLoading(null)
    }
  }

  const filtered = transactions.filter((tx) =>
    statusFilter === 'ALL' ? true : tx.status === statusFilter
  )

  const filterBtnStyle = (active: boolean) => ({
    background: active ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.04)',
    border: active ? '1px solid rgba(99,102,241,0.3)' : '1px solid rgba(255,255,255,0.08)',
    color: active ? '#a5b4fc' : 'rgba(255,255,255,0.5)',
  })

  const statusStyle = {
    PENDING: { color: '#fbbf24', bg: 'rgba(245,158,11,0.1)', border: 'rgba(245,158,11,0.2)' },
    APPROVED: { color: '#34d399', bg: 'rgba(16,185,129,0.1)', border: 'rgba(16,185,129,0.2)' },
    REJECTED: { color: '#f87171', bg: 'rgba(239,68,68,0.1)', border: 'rgba(239,68,68,0.2)' },
  }

  return (
    <div className="p-6 space-y-6">
      <Header title="Transactions" subtitle="Approve, reject, or manage all transactions" />

      {/* Filters */}
      <div
        className="rounded-2xl p-4 flex items-center gap-3"
        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        <Filter className="w-4 h-4 text-gray-500" />
        {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map((s) => (
          <button
            key={s}
            onClick={() => setStatusFilter(s)}
            className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
            style={filterBtnStyle(statusFilter === s)}
          >
            {s === 'ALL' ? 'All' : s.charAt(0) + s.slice(1).toLowerCase()}
            {s !== 'ALL' && (
              <span className="ml-1.5 px-1.5 py-0.5 rounded-full text-xs"
                style={{ background: 'rgba(255,255,255,0.1)' }}
              >
                {transactions.filter(t => t.status === s).length}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Transactions */}
      <div className="space-y-3">
        {loading ? (
          [...Array(5)].map((_, i) => <div key={i} className="h-24 rounded-2xl shimmer" />)
        ) : filtered.length === 0 ? (
          <div
            className="rounded-2xl p-10 text-center"
            style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
          >
            <p className="text-gray-500">No transactions found</p>
          </div>
        ) : (
          filtered.map((tx) => {
            const isExpanded = expandedId === tx.id
            const style = statusStyle[tx.status as keyof typeof statusStyle] || statusStyle.PENDING
            return (
              <div
                key={tx.id}
                className="rounded-2xl overflow-hidden"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
              >
                {/* Header row */}
                <div
                  className="flex items-center justify-between p-5 cursor-pointer"
                  onClick={() => setExpandedId(isExpanded ? null : tx.id)}
                >
                  <div className="flex items-center gap-4">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-semibold text-white">
                          {tx.user?.email}
                        </span>
                        <span
                          className="text-xs px-2 py-0.5 rounded-full font-medium"
                          style={{ background: style.bg, border: `1px solid ${style.border}`, color: style.color }}
                        >
                          {tx.status}
                        </span>
                      </div>
                      <p className="text-xs text-gray-500">
                        {TRANSACTION_TYPE_LABELS[tx.type] || tx.type} • {formatDate(tx.createdAt)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-sm font-bold text-white">{formatCurrency(tx.amountUSD)}</p>
                      {tx.currency !== 'USD' && (
                        <p className="text-xs text-gray-500">{tx.amount} {tx.currency}</p>
                      )}
                    </div>
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4 text-gray-500" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-gray-500" />
                    )}
                  </div>
                </div>

                {/* Expanded details */}
                {isExpanded && (
                  <div
                    className="px-5 pb-5 pt-2 space-y-4"
                    style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}
                  >
                    {/* Details grid */}
                    <div className="grid grid-cols-2 gap-3">
                      {tx.description && (
                        <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                          <p className="text-xs text-gray-500 mb-1">Description</p>
                          <p className="text-sm text-white">{tx.description}</p>
                        </div>
                      )}
                      {tx.recipientEmail && (
                        <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                          <p className="text-xs text-gray-500 mb-1">Recipient</p>
                          <p className="text-sm text-white">{tx.recipientEmail}</p>
                        </div>
                      )}
                      {tx.bankName && (
                        <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                          <p className="text-xs text-gray-500 mb-1">Bank Name</p>
                          <p className="text-sm text-white">{tx.bankName}</p>
                        </div>
                      )}
                      {tx.accountNumber && (
                        <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                          <p className="text-xs text-gray-500 mb-1">Account Number</p>
                          <p className="text-sm text-white">{tx.accountNumber}</p>
                        </div>
                      )}
                      {tx.routingNumber && (
                        <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                          <p className="text-xs text-gray-500 mb-1">Routing Number</p>
                          <p className="text-sm text-white">{tx.routingNumber}</p>
                        </div>
                      )}
                      {tx.ibanNumber && (
                        <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                          <p className="text-xs text-gray-500 mb-1">IBAN</p>
                          <p className="text-sm text-white">{tx.ibanNumber}</p>
                        </div>
                      )}
                      {tx.swiftCode && (
                        <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                          <p className="text-xs text-gray-500 mb-1">SWIFT/BIC</p>
                          <p className="text-sm text-white">{tx.swiftCode}</p>
                        </div>
                      )}
                      <div className="p-3 rounded-xl" style={{ background: 'rgba(255,255,255,0.03)' }}>
                        <p className="text-xs text-gray-500 mb-1">Fee</p>
                        <p className="text-sm text-white">{formatCurrency(tx.fee)}</p>
                      </div>
                    </div>

                    {tx.adminNote && (
                      <div
                        className="p-3 rounded-xl"
                        style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.15)' }}
                      >
                        <p className="text-xs text-indigo-400 mb-1">Admin Note</p>
                        <p className="text-sm text-white">{tx.adminNote}</p>
                      </div>
                    )}

                    {/* Admin note input */}
                    <div>
                      <label className="block text-xs text-gray-500 mb-1.5">Admin Note (optional)</label>
                      <input
                        type="text"
                        value={noteMap[tx.id] || ''}
                        onChange={(e) => setNoteMap({ ...noteMap, [tx.id]: e.target.value })}
                        placeholder="Add a note..."
                        className="w-full px-3 py-2.5 rounded-xl text-sm text-white placeholder-gray-600 outline-none"
                        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                      />
                    </div>

                    {/* Action buttons */}
                    <div className="flex gap-3">
                      <button
                        onClick={() => handleAction(tx.id, 'approve')}
                        disabled={tx.status === 'APPROVED' || !!actionLoading}
                        className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                        style={{ background: 'rgba(16,185,129,0.15)', border: '1px solid rgba(16,185,129,0.3)', color: '#34d399' }}
                      >
                        {actionLoading === `${tx.id}-approve` ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <CheckCircle className="w-4 h-4" />
                        )}
                        Approve
                      </button>
                      <button
                        onClick={() => handleAction(tx.id, 'pending')}
                        disabled={tx.status === 'PENDING' || !!actionLoading}
                        className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                        style={{ background: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.3)', color: '#fbbf24' }}
                      >
                        {actionLoading === `${tx.id}-pending` ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Clock className="w-4 h-4" />
                        )}
                        Set Pending
                      </button>
                      <button
                        onClick={() => handleAction(tx.id, 'reject')}
                        disabled={tx.status === 'REJECTED' || !!actionLoading}
                        className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold transition-all disabled:opacity-40 disabled:cursor-not-allowed"
                        style={{ background: 'rgba(239,68,68,0.15)', border: '1px solid rgba(239,68,68,0.3)', color: '#f87171' }}
                      >
                        {actionLoading === `${tx.id}-reject` ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <XCircle className="w-4 h-4" />
                        )}
                        Reject
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )
          })
        )}
      </div>
    </div>
  )
}

'use client'

import { useEffect, useState } from 'react'
import { Header } from '@/components/layout/Header'
import { Settings, RefreshCw, Loader2, CheckCircle, AlertCircle, Percent } from 'lucide-react'
import { CURRENCY_FLAGS, CURRENCY_NAMES } from '@/lib/utils'

interface ExchangeRate {
  id: string
  currency: string
  rate: number
  source: string
  updatedAt: string
}

interface AdminSettings {
  feePercent: number
}

const CURRENCIES = ['ARS', 'EUR', 'GBP', 'CLP', 'PEN']

export default function AdminSettingsPage() {
  const [rates, setRates] = useState<ExchangeRate[]>([])
  const [settings, setSettings] = useState<AdminSettings | null>(null)
  const [rateEdits, setRateEdits] = useState<Record<string, string>>({})
  const [feeEdit, setFeeEdit] = useState('')
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [saving, setSaving] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchAll()
  }, [])

  const fetchAll = async () => {
    setLoading(true)
    try {
      const [ratesRes, settingsRes] = await Promise.all([
        fetch('/api/exchange-rates'),
        fetch('/api/admin/settings'),
      ])
      const ratesData = await ratesRes.json()
      const settingsData = await settingsRes.json()

      const ratesList = ratesData.rates || []
      setRates(ratesList)

      const edits: Record<string, string> = {}
      ratesList.forEach((r: ExchangeRate) => { edits[r.currency] = r.rate.toString() })
      setRateEdits(edits)

      if (settingsData.settings) {
        setSettings(settingsData.settings)
        setFeeEdit(settingsData.settings.feePercent.toString())
      }
    } finally {
      setLoading(false)
    }
  }

  const handleRefreshRates = async () => {
    setRefreshing(true)
    try {
      await fetch('/api/admin/rates', { method: 'POST' })
      await fetchAll()
      showSuccess('rates-refresh')
    } finally {
      setRefreshing(false)
    }
  }

  const handleSaveRate = async (currency: string) => {
    setSaving(currency)
    try {
      const res = await fetch('/api/admin/rates', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currency, rate: parseFloat(rateEdits[currency]) }),
      })
      if (res.ok) {
        showSuccess(currency)
        await fetchAll()
      } else {
        const d = await res.json()
        setError(d.error || 'Failed to save rate')
      }
    } finally {
      setSaving(null)
    }
  }

  const handleSaveFee = async () => {
    setSaving('fee')
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ feePercent: parseFloat(feeEdit) }),
      })
      if (res.ok) {
        showSuccess('fee')
        await fetchAll()
      } else {
        const d = await res.json()
        setError(d.error || 'Failed to save settings')
      }
    } finally {
      setSaving(null)
    }
  }

  const showSuccess = (key: string) => {
    setSuccess(key)
    setTimeout(() => setSuccess(null), 2000)
  }

  return (
    <div className="p-6 space-y-6">
      <Header title="Settings" subtitle="Manage exchange rates and platform configuration" />

      {error && (
        <div
          className="flex items-center gap-2 p-4 rounded-xl"
          style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)' }}
        >
          <AlertCircle className="w-4 h-4 text-red-400" />
          <p className="text-sm text-red-400">{error}</p>
        </div>
      )}

      {/* Fee settings */}
      <div
        className="rounded-2xl p-6"
        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        <div className="flex items-center gap-3 mb-5">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: 'rgba(99,102,241,0.1)' }}
          >
            <Percent className="w-4 h-4 text-indigo-400" />
          </div>
          <div>
            <h3 className="font-semibold text-white">Transaction Fee</h3>
            <p className="text-xs text-gray-500">Applied to all transactions</p>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex-1">
            <label className="block text-sm text-gray-400 mb-2">Fee Percentage (%)</label>
            <div className="relative">
              <input
                type="number"
                value={feeEdit}
                onChange={(e) => setFeeEdit(e.target.value)}
                min="0"
                max="10"
                step="0.1"
                className="w-full px-4 py-3 pr-8 rounded-xl text-white outline-none transition-all"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400">%</span>
            </div>
          </div>
          <div className="mt-6">
            <button
              onClick={handleSaveFee}
              disabled={saving === 'fee'}
              className="px-5 py-3 rounded-xl text-sm font-semibold text-white flex items-center gap-2 transition-all disabled:opacity-50"
              style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
            >
              {saving === 'fee' ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : success === 'fee' ? (
                <CheckCircle className="w-4 h-4" />
              ) : (
                <Settings className="w-4 h-4" />
              )}
              {success === 'fee' ? 'Saved!' : 'Save'}
            </button>
          </div>
        </div>
        <p className="text-xs text-gray-600 mt-2">
          Current: {settings?.feePercent ?? 0.5}% • Options: 0.5% or 1%
        </p>
      </div>

      {/* Exchange rates */}
      <div
        className="rounded-2xl p-6"
        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-3">
            <div
              className="w-9 h-9 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(6,182,212,0.1)' }}
            >
              <RefreshCw className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h3 className="font-semibold text-white">Exchange Rates</h3>
              <p className="text-xs text-gray-500">Units of currency per 1 USD</p>
            </div>
          </div>
          <button
            onClick={handleRefreshRates}
            disabled={refreshing}
            className="flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium text-cyan-400 transition-all"
            style={{ background: 'rgba(6,182,212,0.1)', border: '1px solid rgba(6,182,212,0.2)' }}
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
            {success === 'rates-refresh' ? 'Updated!' : 'Refresh from API'}
          </button>
        </div>

        {loading ? (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => <div key={i} className="h-16 rounded-xl shimmer" />)}
          </div>
        ) : (
          <div className="space-y-3">
            {CURRENCIES.map((currency) => {
              const rate = rates.find((r) => r.currency === currency)
              return (
                <div
                  key={currency}
                  className="flex items-center gap-4 p-4 rounded-xl"
                  style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}
                >
                  <div className="w-32 flex items-center gap-2 shrink-0">
                    <span className="text-xl">{CURRENCY_FLAGS[currency]}</span>
                    <div>
                      <p className="text-sm font-bold text-white">{currency}</p>
                      <p className="text-xs text-gray-500">{CURRENCY_NAMES[currency]}</p>
                    </div>
                  </div>
                  <div className="flex-1">
                    <input
                      type="number"
                      value={rateEdits[currency] || ''}
                      onChange={(e) => setRateEdits({ ...rateEdits, [currency]: e.target.value })}
                      placeholder="0.00"
                      step="0.0001"
                      className="w-full px-3 py-2 rounded-xl text-white text-sm outline-none"
                      style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                    />
                  </div>
                  <div className="text-xs text-gray-600 shrink-0 w-20">
                    {rate ? (
                      <span>Source: {rate.source}</span>
                    ) : null}
                  </div>
                  <button
                    onClick={() => handleSaveRate(currency)}
                    disabled={!!saving}
                    className="shrink-0 px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all disabled:opacity-50"
                    style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)', color: '#34d399' }}
                  >
                    {saving === currency ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : success === currency ? (
                      <CheckCircle className="w-3.5 h-3.5" />
                    ) : null}
                    {success === currency ? 'Saved!' : 'Save'}
                  </button>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

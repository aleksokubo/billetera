'use client'

import { useEffect, useState } from 'react'
import { Header } from '@/components/layout/Header'
import { Users, ArrowRightLeft, DollarSign, Clock, TrendingUp, CheckCircle, XCircle } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'
import Link from 'next/link'

interface Stats {
  totalUsers: number
  pendingTransactions: number
  approvedTransactions: number
  rejectedTransactions: number
  totalVolume: number
  todayVolume: number
  recentTransactions: any[]
}

export default function AdminDashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/admin/stats')
      .then((r) => r.json())
      .then((d) => {
        setStats(d)
        setLoading(false)
      })
      .catch(() => setLoading(false))
  }, [])

  const statCards = stats ? [
    {
      label: 'Total Users',
      value: stats.totalUsers.toString(),
      icon: Users,
      color: '#6366f1',
      bg: 'rgba(99,102,241,0.1)',
    },
    {
      label: 'Pending Transactions',
      value: stats.pendingTransactions.toString(),
      icon: Clock,
      color: '#f59e0b',
      bg: 'rgba(245,158,11,0.1)',
    },
    {
      label: 'Total Volume',
      value: formatCurrency(stats.totalVolume),
      icon: DollarSign,
      color: '#10b981',
      bg: 'rgba(16,185,129,0.1)',
    },
    {
      label: 'Today\'s Volume',
      value: formatCurrency(stats.todayVolume),
      icon: TrendingUp,
      color: '#06b6d4',
      bg: 'rgba(6,182,212,0.1)',
    },
  ] : []

  return (
    <div className="p-6 space-y-6">
      <Header title="Admin Overview" subtitle="Monitor and manage all platform activity" />

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {loading
          ? [...Array(4)].map((_, i) => (
              <div key={i} className="h-28 rounded-2xl shimmer" />
            ))
          : statCards.map((card) => {
              const Icon = card.icon
              return (
                <div
                  key={card.label}
                  className="rounded-2xl p-5"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ background: card.bg }}
                    >
                      <Icon className="w-5 h-5" style={{ color: card.color }} />
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-white">{card.value}</div>
                  <div className="text-sm text-gray-400 mt-1">{card.label}</div>
                </div>
              )
            })}
      </div>

      {/* Transaction status overview */}
      {stats && (
        <div className="grid grid-cols-3 gap-4">
          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(245,158,11,0.08)', border: '1px solid rgba(245,158,11,0.2)' }}
          >
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-amber-400" />
              <span className="text-sm text-amber-400 font-medium">Pending</span>
            </div>
            <div className="text-3xl font-bold text-amber-300">{stats.pendingTransactions}</div>
          </div>
          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)' }}
          >
            <div className="flex items-center gap-2 mb-2">
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-emerald-400 font-medium">Approved</span>
            </div>
            <div className="text-3xl font-bold text-emerald-300">{stats.approvedTransactions}</div>
          </div>
          <div
            className="rounded-2xl p-5"
            style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)' }}
          >
            <div className="flex items-center gap-2 mb-2">
              <XCircle className="w-4 h-4 text-red-400" />
              <span className="text-sm text-red-400 font-medium">Rejected</span>
            </div>
            <div className="text-3xl font-bold text-red-300">{stats.rejectedTransactions}</div>
          </div>
        </div>
      )}

      {/* Recent transactions preview */}
      <div
        className="rounded-2xl"
        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        <div className="flex items-center justify-between p-5 pb-4">
          <h3 className="font-semibold text-white">Recent Transactions</h3>
          <Link href="/admin/transactions" className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors">
            View all
          </Link>
        </div>
        {loading ? (
          <div className="px-5 pb-5 space-y-3">
            {[...Array(3)].map((_, i) => <div key={i} className="h-16 rounded-xl shimmer" />)}
          </div>
        ) : stats?.recentTransactions?.length ? (
          <div className="px-5 pb-5 space-y-2">
            {stats.recentTransactions.map((tx: any) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-4 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <div>
                  <p className="text-sm font-medium text-white">{tx.user?.email}</p>
                  <p className="text-xs text-gray-500">{tx.type}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold text-white">{formatCurrency(tx.amountUSD)}</p>
                  <span
                    className="text-xs px-2 py-0.5 rounded-full"
                    style={{
                      background: tx.status === 'PENDING' ? 'rgba(245,158,11,0.1)' : tx.status === 'APPROVED' ? 'rgba(16,185,129,0.1)' : 'rgba(239,68,68,0.1)',
                      color: tx.status === 'PENDING' ? '#fbbf24' : tx.status === 'APPROVED' ? '#34d399' : '#f87171',
                    }}
                  >
                    {tx.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-10 text-center text-gray-500">No transactions yet</div>
        )}
      </div>
    </div>
  )
}

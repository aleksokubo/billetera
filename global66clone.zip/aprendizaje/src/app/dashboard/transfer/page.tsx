'use client'

import { useState } from 'react'
import { Header } from '@/components/layout/Header'
import { ArrowRightLeft, Loader2, CheckCircle, AlertCircle } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

type TransferType = 'ACH' | 'SEPA' | 'BANK'

export default function TransferPage() {
  const [transferType, setTransferType] = useState<TransferType>('ACH')
  const [amount, setAmount] = useState('')
  const [form, setForm] = useState({
    bankName: '',
    accountNumber: '',
    routingNumber: '',
    ibanNumber: '',
    swiftCode: '',
    description: '',
  })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value })
  }

  const amountNum = parseFloat(amount) || 0
  const fee = amountNum * 0.01 // 1% for bank transfers
  const total = amountNum + fee

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess(false)

    const transferData: any = {
      type: `TRANSFER_${transferType}`,
      amount: amountNum,
      description: form.description,
      bankName: form.bankName,
    }

    if (transferType === 'ACH') {
      transferData.accountNumber = form.accountNumber
      transferData.routingNumber = form.routingNumber
    } else if (transferType === 'SEPA') {
      transferData.ibanNumber = form.ibanNumber
      transferData.swiftCode = form.swiftCode
    } else {
      transferData.accountNumber = form.accountNumber
      transferData.swiftCode = form.swiftCode
    }

    try {
      const res = await fetch('/api/wallet/transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(transferData),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Transfer failed')
      } else {
        setSuccess(true)
        setAmount('')
        setForm({ bankName: '', accountNumber: '', routingNumber: '', ibanNumber: '', swiftCode: '', description: '' })
      }
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const transferTypes = [
    { id: 'ACH' as TransferType, label: 'ACH', description: 'US Bank Transfer', color: '#10b981' },
    { id: 'SEPA' as TransferType, label: 'SEPA', description: 'European Transfer', color: '#6366f1' },
    { id: 'BANK' as TransferType, label: 'Wire', description: 'International Wire', color: '#8b5cf6' },
  ]

  const inputStyle = {
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(255,255,255,0.1)',
  }

  return (
    <div className="p-6 space-y-6">
      <Header title="Bank Transfer" subtitle="Transfer funds to a bank account" />

      <div className="max-w-xl mx-auto">
        <div
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(139,92,246,0.1)', border: '1px solid rgba(139,92,246,0.2)' }}
            >
              <ArrowRightLeft className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Bank Transfer</h2>
              <p className="text-sm text-gray-400">Select transfer type and fill details</p>
            </div>
          </div>

          {/* Transfer type selector */}
          <div className="grid grid-cols-3 gap-3 mb-6">
            {transferTypes.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTransferType(t.id)}
                className="p-3 rounded-xl text-center transition-all duration-200"
                style={{
                  background: transferType === t.id ? `${t.color}20` : 'rgba(255,255,255,0.04)',
                  border: transferType === t.id ? `1px solid ${t.color}50` : '1px solid rgba(255,255,255,0.08)',
                }}
              >
                <div className="text-sm font-bold" style={{ color: transferType === t.id ? t.color : 'white' }}>
                  {t.label}
                </div>
                <div className="text-xs text-gray-500 mt-0.5">{t.description}</div>
              </button>
            ))}
          </div>

          {success && (
            <div
              className="flex items-center gap-3 p-4 rounded-xl mb-5"
              style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}
            >
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
              <p className="text-sm font-medium text-emerald-400">Transfer submitted for admin approval!</p>
            </div>
          )}

          {error && (
            <div
              className="flex items-center gap-3 p-4 rounded-xl mb-5"
              style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)' }}
            >
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Amount (USD)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-semibold">$</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  min="0.01"
                  step="0.01"
                  required
                  className="w-full pl-8 pr-4 py-3 rounded-xl text-white text-lg font-semibold placeholder-gray-700 outline-none transition-all duration-200"
                  style={inputStyle}
                  onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                  onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Bank Name</label>
              <input
                type="text"
                name="bankName"
                value={form.bankName}
                onChange={handleChange}
                placeholder="Chase Bank, Bank of America..."
                required
                className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                style={inputStyle}
                onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
              />
            </div>

            {/* ACH fields */}
            {transferType === 'ACH' && (
              <>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Account Number</label>
                  <input
                    type="text"
                    name="accountNumber"
                    value={form.accountNumber}
                    onChange={handleChange}
                    placeholder="123456789"
                    required
                    className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                    style={inputStyle}
                    onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                    onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Routing Number</label>
                  <input
                    type="text"
                    name="routingNumber"
                    value={form.routingNumber}
                    onChange={handleChange}
                    placeholder="021000021"
                    required
                    maxLength={9}
                    className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                    style={inputStyle}
                    onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                    onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                  />
                </div>
              </>
            )}

            {/* SEPA fields */}
            {transferType === 'SEPA' && (
              <>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">IBAN</label>
                  <input
                    type="text"
                    name="ibanNumber"
                    value={form.ibanNumber}
                    onChange={handleChange}
                    placeholder="DE89370400440532013000"
                    required
                    className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                    style={inputStyle}
                    onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                    onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">BIC/SWIFT</label>
                  <input
                    type="text"
                    name="swiftCode"
                    value={form.swiftCode}
                    onChange={handleChange}
                    placeholder="DEUTDEDB"
                    required
                    className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                    style={inputStyle}
                    onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                    onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                  />
                </div>
              </>
            )}

            {/* BANK wire fields */}
            {transferType === 'BANK' && (
              <>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">Account Number</label>
                  <input
                    type="text"
                    name="accountNumber"
                    value={form.accountNumber}
                    onChange={handleChange}
                    placeholder="123456789"
                    required
                    className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                    style={inputStyle}
                    onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                    onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                  />
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">SWIFT Code</label>
                  <input
                    type="text"
                    name="swiftCode"
                    value={form.swiftCode}
                    onChange={handleChange}
                    placeholder="CHASUS33"
                    required
                    className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                    style={inputStyle}
                    onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                    onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                  />
                </div>
              </>
            )}

            <div>
              <label className="block text-sm text-gray-400 mb-2">Reference (optional)</label>
              <input
                type="text"
                name="description"
                value={form.description}
                onChange={handleChange}
                placeholder="Invoice #1234, Rent payment..."
                className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                style={inputStyle}
                onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
              />
            </div>

            {amountNum > 0 && (
              <div
                className="rounded-xl p-4 space-y-2"
                style={{ background: 'rgba(139,92,246,0.08)', border: '1px solid rgba(139,92,246,0.15)' }}
              >
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Transfer amount</span>
                  <span className="text-white">{formatCurrency(amountNum)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Fee (1%)</span>
                  <span className="text-amber-400">-{formatCurrency(fee)}</span>
                </div>
                <div className="border-t pt-2 mt-2 flex justify-between" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
                  <span className="text-sm font-semibold text-white">Total deducted</span>
                  <span className="text-red-400 font-bold">{formatCurrency(total)}</span>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !amount || amountNum <= 0}
              className="w-full py-3 rounded-xl font-semibold text-white flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowRightLeft className="w-5 h-5" />}
              {loading ? 'Submitting...' : `Submit ${transferType} Transfer`}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

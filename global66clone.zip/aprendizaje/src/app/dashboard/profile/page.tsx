'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Header } from '@/components/layout/Header'
import { User, Camera, Upload, Loader2, CheckCircle, AlertCircle, Shield, Check } from 'lucide-react'

export default function ProfilePage() {
  const { data: session, update } = useSession()
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    name: '',
  })
  const [photo, setPhoto] = useState<string | null>(null)
  const [kycDocument, setKycDocument] = useState<string | null>(null)
  const [kycStatus, setKycStatus] = useState<string>('PENDING')
  const [loading, setLoading] = useState(false)
  const [kycLoading, setKycLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [kycSuccess, setKycSuccess] = useState(false)
  const [error, setError] = useState('')
  const photoRef = useRef<HTMLInputElement>(null)
  const docRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (session?.user) {
      fetch('/api/profile/update')
        .then((r) => r.json())
        .then((d) => {
          setForm({
            firstName: d.firstName || '',
            lastName: d.lastName || '',
            name: d.name || '',
          })
          setKycStatus(d.kycStatus || 'PENDING')
          if (d.image) setPhoto(d.image)
        })
        .catch(console.error)
    }
  }, [session])

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.size > 5 * 1024 * 1024) {
      setError('Photo must be under 5MB')
      return
    }

    const reader = new FileReader()
    reader.onload = () => setPhoto(reader.result as string)
    reader.readAsDataURL(file)
  }

  const handleDocChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.size > 10 * 1024 * 1024) {
      setError('Document must be under 10MB')
      return
    }

    const reader = new FileReader()
    reader.onload = () => setKycDocument(reader.result as string)
    reader.readAsDataURL(file)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess(false)

    try {
      const res = await fetch('/api/profile/update', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, image: photo }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Update failed')
      } else {
        setSuccess(true)
        await update()
      }
    } catch {
      setError('Something went wrong.')
    } finally {
      setLoading(false)
    }
  }

  const handleKycSubmit = async () => {
    if (!kycDocument) return
    setKycLoading(true)
    setError('')

    try {
      const res = await fetch('/api/profile/kyc', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ document: kycDocument }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'KYC submission failed')
      } else {
        setKycSuccess(true)
        setKycStatus('PENDING')
      }
    } catch {
      setError('KYC submission failed.')
    } finally {
      setKycLoading(false)
    }
  }

  const kycStatusStyle = {
    PENDING: { color: '#fbbf24', bg: 'rgba(245,158,11,0.1)', border: 'rgba(245,158,11,0.2)', label: 'Pending Review' },
    VERIFIED: { color: '#34d399', bg: 'rgba(16,185,129,0.1)', border: 'rgba(16,185,129,0.2)', label: 'Verified' },
    REJECTED: { color: '#f87171', bg: 'rgba(239,68,68,0.1)', border: 'rgba(239,68,68,0.2)', label: 'Rejected' },
  }

  const kycStyle = kycStatusStyle[kycStatus as keyof typeof kycStatusStyle] || kycStatusStyle.PENDING

  return (
    <div className="p-6 space-y-6">
      <Header title="Profile" subtitle="Manage your account information" />

      <div className="max-w-2xl mx-auto space-y-6">
        {/* Profile Photo */}
        <div
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          <h3 className="text-sm font-semibold text-gray-300 mb-4">Profile Photo</h3>
          <div className="flex items-center gap-6">
            <div className="relative">
              <div
                className="w-24 h-24 rounded-2xl flex items-center justify-center overflow-hidden text-3xl font-bold"
                style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
              >
                {photo ? (
                  <img src={photo} alt="Profile" className="w-full h-full object-cover" />
                ) : (
                  session?.user?.name?.charAt(0)?.toUpperCase() || 'U'
                )}
              </div>
              <button
                onClick={() => photoRef.current?.click()}
                className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full flex items-center justify-center text-white transition-all"
                style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', border: '2px solid #0a0f1e' }}
              >
                <Camera className="w-4 h-4" />
              </button>
              <input ref={photoRef} type="file" accept="image/*" onChange={handlePhotoChange} className="hidden" />
            </div>
            <div>
              <p className="text-white font-medium">{session?.user?.name || 'Your Name'}</p>
              <p className="text-gray-400 text-sm">{session?.user?.email}</p>
              <button
                onClick={() => photoRef.current?.click()}
                className="mt-2 text-xs text-indigo-400 hover:text-indigo-300 transition-colors"
              >
                Change photo
              </button>
            </div>
          </div>
        </div>

        {/* Profile form */}
        <div
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          <div className="flex items-center gap-3 mb-5">
            <User className="w-5 h-5 text-indigo-400" />
            <h3 className="text-sm font-semibold text-gray-300">Personal Information</h3>
          </div>

          {success && (
            <div
              className="flex items-center gap-2 p-3 rounded-xl mb-4"
              style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}
            >
              <CheckCircle className="w-4 h-4 text-emerald-400" />
              <p className="text-sm text-emerald-400">Profile updated successfully</p>
            </div>
          )}

          {error && (
            <div
              className="flex items-center gap-2 p-3 rounded-xl mb-4"
              style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)' }}
            >
              <AlertCircle className="w-4 h-4 text-red-400" />
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">First Name</label>
                <input
                  type="text"
                  value={form.firstName}
                  onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                  placeholder="John"
                  className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                  onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                  onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                />
              </div>
              <div>
                <label className="block text-sm text-gray-400 mb-2">Last Name</label>
                <input
                  type="text"
                  value={form.lastName}
                  onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                  placeholder="Doe"
                  className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                  onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                  onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Display Name</label>
              <input
                type="text"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Your display name"
                className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Email</label>
              <input
                type="email"
                value={session?.user?.email || ''}
                disabled
                className="w-full px-4 py-3 rounded-xl text-gray-500 outline-none cursor-not-allowed"
                style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.06)' }}
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl font-semibold text-white flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50"
              style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
              {loading ? 'Saving...' : 'Save Changes'}
            </button>
          </form>
        </div>

        {/* KYC Verification */}
        <div
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-indigo-400" />
              <h3 className="text-sm font-semibold text-gray-300">Identity Verification (KYC)</h3>
            </div>
            <div
              className="px-3 py-1 rounded-full text-xs font-semibold"
              style={{ background: kycStyle.bg, border: `1px solid ${kycStyle.border}`, color: kycStyle.color }}
            >
              {kycStyle.label}
            </div>
          </div>

          {kycStatus === 'VERIFIED' ? (
            <div className="flex items-center gap-3 p-4 rounded-xl" style={{ background: 'rgba(16,185,129,0.08)' }}>
              <CheckCircle className="w-8 h-8 text-emerald-400" />
              <div>
                <p className="text-white font-medium">Identity Verified</p>
                <p className="text-gray-400 text-sm">Your identity has been successfully verified</p>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="text-gray-400 text-sm">
                Upload a government-issued ID (passport, driver&apos;s license, or national ID) to verify your identity.
              </p>

              {kycSuccess && (
                <div
                  className="flex items-center gap-2 p-3 rounded-xl"
                  style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}
                >
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                  <p className="text-sm text-emerald-400">Document submitted for review</p>
                </div>
              )}

              <div
                className="border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all"
                style={{ borderColor: kycDocument ? 'rgba(16,185,129,0.4)' : 'rgba(255,255,255,0.1)' }}
                onClick={() => docRef.current?.click()}
              >
                <input ref={docRef} type="file" accept="image/*,.pdf" onChange={handleDocChange} className="hidden" />
                {kycDocument ? (
                  <div className="flex flex-col items-center gap-2">
                    <CheckCircle className="w-10 h-10 text-emerald-400" />
                    <p className="text-emerald-400 font-medium">Document selected</p>
                    <p className="text-gray-500 text-xs">Click to change</p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-2">
                    <Upload className="w-10 h-10 text-gray-600" />
                    <p className="text-gray-400 font-medium">Click to upload document</p>
                    <p className="text-gray-600 text-xs">JPG, PNG, or PDF (max 10MB)</p>
                  </div>
                )}
              </div>

              <button
                onClick={handleKycSubmit}
                disabled={!kycDocument || kycLoading}
                className="w-full py-3 rounded-xl font-semibold text-white flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                style={{ background: 'linear-gradient(135deg, #10b981, #059669)' }}
              >
                {kycLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
                {kycLoading ? 'Submitting...' : 'Submit for Verification'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

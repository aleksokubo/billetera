'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/Header'
import { ArrowDownCircle, Loader2, CheckCircle, AlertCircle, RefreshCw } from 'lucide-react'
import { formatCurrency, CURRENCY_FLAGS, CURRENCY_NAMES } from '@/lib/utils'

const CURRENCIES = ['ARS', 'EUR', 'GBP', 'CLP', 'PEN']

interface ExchangeRate {
  currency: string
  rate: number
}

export default function LoadPage() {
  const [amount, setAmount] = useState('')
  const [currency, setCurrency] = useState('ARS')
  const [rates, setRates] = useState<Record<string, number>>({})
  const [loading, setLoading] = useState(false)
  const [fetchingRates, setFetchingRates] = useState(true)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    fetchRates()
  }, [])

  const fetchRates = async () => {
    setFetchingRates(true)
    try {
      const res = await fetch('/api/exchange-rates')
      const data = await res.json()
      if (data.rates) {
        const ratesMap: Record<string, number> = {}
        data.rates.forEach((r: ExchangeRate) => { ratesMap[r.currency] = r.rate })
        setRates(ratesMap)
      }
    } catch {
      console.error('Failed to fetch rates')
    } finally {
      setFetchingRates(false)
    }
  }

  const amountNum = parseFloat(amount) || 0
  const currentRate = rates[currency] || 1
  const amountUSD = currency === 'USD' ? amountNum : amountNum / currentRate
  const fee = amountUSD * 0.005
  const netAmountUSD = amountUSD - fee

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!amount || amountNum <= 0) return

    setLoading(true)
    setError('')
    setSuccess(false)

    try {
      const res = await fetch('/api/wallet/load', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: amountNum, currency }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Failed to submit request')
      } else {
        setSuccess(true)
        setAmount('')
      }
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-6 space-y-6">
      <Header title="Load Balance" subtitle="Add funds to your USD wallet" />

      <div className="max-w-xl mx-auto">
        {/* Exchange rates card */}
        <div
          className="rounded-2xl p-5 mb-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-gray-300">Live Exchange Rates</h3>
            <button
              onClick={fetchRates}
              className="p-1.5 rounded-lg text-gray-500 hover:text-gray-300 transition-colors"
              style={{ background: 'rgba(255,255,255,0.05)' }}
            >
              <RefreshCw className={`w-3.5 h-3.5 ${fetchingRates ? 'animate-spin' : ''}`} />
            </button>
          </div>
          <div className="grid grid-cols-3 gap-2">
            {CURRENCIES.map((cur) => (
              <div
                key={cur}
                className="p-3 rounded-xl text-center"
                style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
              >
                <div className="text-lg mb-1">{CURRENCY_FLAGS[cur]}</div>
                <div className="text-xs font-bold text-white">{cur}</div>
                <div className="text-xs text-gray-500 mt-0.5">
                  {fetchingRates ? '...' : rates[cur] ? `${rates[cur].toFixed(2)} / $1` : 'N/A'}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Load form */}
        <div
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}
            >
              <ArrowDownCircle className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Load Funds</h2>
              <p className="text-sm text-gray-400">Submit a load request for admin review</p>
            </div>
          </div>

          {success && (
            <div
              className="flex items-center gap-3 p-4 rounded-xl mb-5"
              style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}
            >
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="text-sm font-medium text-emerald-400">Request submitted!</p>
                <p className="text-xs text-emerald-400/70 mt-0.5">Your load request is pending admin approval.</p>
              </div>
            </div>
          )}

          {error && (
            <div
              className="flex items-center gap-3 p-4 rounded-xl mb-5"
              style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)' }}
            >
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Currency selector */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Currency</label>
              <div className="grid grid-cols-3 gap-2">
                {CURRENCIES.map((cur) => (
                  <button
                    key={cur}
                    type="button"
                    onClick={() => setCurrency(cur)}
                    className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200"
                    style={{
                      background: currency === cur ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.04)',
                      border: currency === cur ? '1px solid rgba(99,102,241,0.4)' : '1px solid rgba(255,255,255,0.07)',
                      color: currency === cur ? '#a5b4fc' : 'rgba(255,255,255,0.5)',
                    }}
                  >
                    <span>{CURRENCY_FLAGS[cur]}</span>
                    <span>{cur}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Amount input */}
            <div>
              <label className="block text-sm text-gray-400 mb-2">Amount ({currency})</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-medium">
                  {CURRENCY_FLAGS[currency]}
                </span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  min="0"
                  step="0.01"
                  required
                  className="w-full pl-10 pr-4 py-3 rounded-xl text-white text-xl font-semibold placeholder-gray-700 outline-none transition-all duration-200"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                  onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                  onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                />
              </div>
            </div>

            {/* Conversion summary */}
            {amountNum > 0 && (
              <div
                className="rounded-xl p-4 space-y-2"
                style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.15)' }}
              >
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Amount</span>
                  <span className="text-white">{amountNum.toFixed(2)} {currency}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Exchange rate</span>
                  <span className="text-white">1 USD = {currentRate.toFixed(2)} {currency}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Amount in USD</span>
                  <span className="text-white">{formatCurrency(amountUSD)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Fee (0.5%)</span>
                  <span className="text-amber-400">-{formatCurrency(fee)}</span>
                </div>
                <div className="border-t pt-2 mt-2 flex justify-between" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
                  <span className="text-sm font-semibold text-white">You&apos;ll receive</span>
                  <span className="text-emerald-400 font-bold">{formatCurrency(netAmountUSD)}</span>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !amount || amountNum <= 0}
              className="w-full py-3 rounded-xl font-semibold text-white flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <ArrowDownCircle className="w-5 h-5" />}
              {loading ? 'Submitting...' : 'Submit Load Request'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

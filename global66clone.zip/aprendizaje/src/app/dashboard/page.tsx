'use client'

import { useSession } from 'next-auth/react'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Header } from '@/components/layout/Header'
import {
  ArrowDownCircle,
  Send,
  ArrowRightLeft,
  History,
  TrendingUp,
  TrendingDown,
  Clock,
  CheckCircle,
  XCircle,
} from 'lucide-react'
import { formatCurrency, formatDate, TRANSACTION_TYPE_LABELS, STATUS_COLORS } from '@/lib/utils'

interface Transaction {
  id: string
  type: string
  amount: number
  currency: string
  amountUSD: number
  status: string
  description: string | null
  createdAt: string
}

export default function DashboardPage() {
  const { data: session } = useSession()
  const [balance, setBalance] = useState<number | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loadingBalance, setLoadingBalance] = useState(true)
  const [loadingTx, setLoadingTx] = useState(true)

  useEffect(() => {
    fetch('/api/wallet/balance')
      .then((r) => r.json())
      .then((d) => {
        setBalance(d.balance ?? 0)
        setLoadingBalance(false)
      })
      .catch(() => setLoadingBalance(false))

    fetch('/api/transactions?limit=5')
      .then((r) => r.json())
      .then((d) => {
        setTransactions(d.transactions || [])
        setLoadingTx(false)
      })
      .catch(() => setLoadingTx(false))
  }, [])

  const quickActions = [
    { href: '/dashboard/load', icon: ArrowDownCircle, label: 'Load', color: '#10b981' },
    { href: '/dashboard/send', icon: Send, label: 'Send', color: '#6366f1' },
    { href: '/dashboard/transfer', icon: ArrowRightLeft, label: 'Transfer', color: '#8b5cf6' },
    { href: '/dashboard/history', icon: History, label: 'History', color: '#06b6d4' },
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'APPROVED': return <CheckCircle className="w-4 h-4 text-emerald-400" />
      case 'REJECTED': return <XCircle className="w-4 h-4 text-red-400" />
      default: return <Clock className="w-4 h-4 text-amber-400" />
    }
  }

  const firstName = session?.user?.name?.split(' ')[0] || 'there'

  return (
    <div className="p-6 space-y-6">
      <Header title={`Hello, ${firstName} 👋`} subtitle="Here's your financial overview" />

      {/* Balance Card */}
      <div
        className="rounded-2xl p-8 relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, rgba(99,102,241,0.3) 0%, rgba(139,92,246,0.3) 50%, rgba(6,182,212,0.2) 100%)',
          border: '1px solid rgba(99,102,241,0.3)',
        }}
      >
        {/* Decorative orb */}
        <div
          className="absolute -right-16 -top-16 w-64 h-64 rounded-full"
          style={{ background: 'radial-gradient(circle, rgba(99,102,241,0.2) 0%, transparent 70%)' }}
        />
        <div className="relative">
          <p className="text-gray-300 text-sm font-medium mb-2">Total Balance</p>
          {loadingBalance ? (
            <div className="h-12 w-48 rounded-xl shimmer mb-2" />
          ) : (
            <h2 className="text-5xl font-bold text-white mb-2">
              {formatCurrency(balance ?? 0)}
            </h2>
          )}
          <p className="text-indigo-300 text-sm">USD Wallet</p>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-4 gap-4">
        {quickActions.map((action) => {
          const Icon = action.icon
          return (
            <Link
              key={action.href}
              href={action.href}
              className="flex flex-col items-center gap-3 p-5 rounded-2xl text-center transition-all duration-200 hover:scale-105"
              style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(255,255,255,0.1)',
              }}
            >
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center"
                style={{ background: `${action.color}20`, border: `1px solid ${action.color}30` }}
              >
                <Icon className="w-6 h-6" style={{ color: action.color }} />
              </div>
              <span className="text-sm font-medium text-gray-300">{action.label}</span>
            </Link>
          )
        })}
      </div>

      {/* Recent Transactions */}
      <div
        className="rounded-2xl"
        style={{
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(255,255,255,0.1)',
        }}
      >
        <div className="flex items-center justify-between p-5 pb-4">
          <h3 className="font-semibold text-white">Recent Transactions</h3>
          <Link href="/dashboard/history" className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors">
            View all
          </Link>
        </div>

        {loadingTx ? (
          <div className="p-5 pt-0 space-y-3">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-16 rounded-xl shimmer" />
            ))}
          </div>
        ) : transactions.length === 0 ? (
          <div className="p-10 text-center">
            <History className="w-10 h-10 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-500">No transactions yet</p>
            <p className="text-gray-600 text-sm mt-1">Load your wallet to get started</p>
          </div>
        ) : (
          <div className="px-5 pb-5 space-y-2">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between p-4 rounded-xl transition-colors"
                style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center"
                    style={{ background: tx.type === 'LOAD' ? 'rgba(16,185,129,0.1)' : 'rgba(99,102,241,0.1)' }}
                  >
                    {tx.type === 'LOAD' ? (
                      <TrendingUp className="w-5 h-5 text-emerald-400" />
                    ) : (
                      <TrendingDown className="w-5 h-5 text-indigo-400" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">
                      {TRANSACTION_TYPE_LABELS[tx.type] || tx.type}
                    </p>
                    <p className="text-xs text-gray-500">{formatDate(tx.createdAt)}</p>
                  </div>
                </div>
                <div className="text-right flex items-center gap-3">
                  <div>
                    <p className="text-sm font-semibold" style={{ color: tx.type === 'LOAD' ? '#10b981' : '#f87171' }}>
                      {tx.type === 'LOAD' ? '+' : '-'}{formatCurrency(tx.amountUSD)}
                    </p>
                    {tx.currency !== 'USD' && (
                      <p className="text-xs text-gray-500">{tx.amount} {tx.currency}</p>
                    )}
                  </div>
                  {getStatusIcon(tx.status)}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}

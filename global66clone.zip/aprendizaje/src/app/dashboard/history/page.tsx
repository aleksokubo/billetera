'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/Header'
import { History, TrendingUp, TrendingDown, Filter, Clock, CheckCircle, XCircle } from 'lucide-react'
import { formatCurrency, formatDate, TRANSACTION_TYPE_LABELS, CURRENCY_FLAGS } from '@/lib/utils'

interface Transaction {
  id: string
  type: string
  amount: number
  currency: string
  amountUSD: number
  exchangeRate: number
  fee: number
  status: string
  description: string | null
  recipientEmail: string | null
  bankName: string | null
  createdAt: string
}

const STATUS_STYLES: Record<string, { bg: string; border: string; text: string }> = {
  PENDING: { bg: 'rgba(245,158,11,0.1)', border: 'rgba(245,158,11,0.2)', text: '#fbbf24' },
  APPROVED: { bg: 'rgba(16,185,129,0.1)', border: 'rgba(16,185,129,0.2)', text: '#34d399' },
  REJECTED: { bg: 'rgba(239,68,68,0.1)', border: 'rgba(239,68,68,0.2)', text: '#f87171' },
}

export default function HistoryPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [statusFilter, setStatusFilter] = useState('ALL')
  const [typeFilter, setTypeFilter] = useState('ALL')

  useEffect(() => {
    fetchTransactions()
  }, [])

  const fetchTransactions = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/transactions')
      const data = await res.json()
      setTransactions(data.transactions || [])
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const filtered = transactions.filter((tx) => {
    const statusOk = statusFilter === 'ALL' || tx.status === statusFilter
    const typeOk = typeFilter === 'ALL' || tx.type === typeFilter
    return statusOk && typeOk
  })

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'APPROVED': return <CheckCircle className="w-4 h-4 text-emerald-400" />
      case 'REJECTED': return <XCircle className="w-4 h-4 text-red-400" />
      default: return <Clock className="w-4 h-4 text-amber-400" />
    }
  }

  const filterBtnStyle = (active: boolean) => ({
    background: active ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.04)',
    border: active ? '1px solid rgba(99,102,241,0.3)' : '1px solid rgba(255,255,255,0.08)',
    color: active ? '#a5b4fc' : 'rgba(255,255,255,0.5)',
  })

  return (
    <div className="p-6 space-y-6">
      <Header title="Transaction History" subtitle="All your past transactions" />

      {/* Filters */}
      <div
        className="rounded-2xl p-5"
        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        <div className="flex flex-wrap gap-4">
          <div>
            <label className="block text-xs text-gray-500 mb-2 flex items-center gap-1.5">
              <Filter className="w-3 h-3" /> Status
            </label>
            <div className="flex gap-2">
              {['ALL', 'PENDING', 'APPROVED', 'REJECTED'].map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                  style={filterBtnStyle(statusFilter === s)}
                >
                  {s === 'ALL' ? 'All' : s.charAt(0) + s.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-2">Type</label>
            <div className="flex flex-wrap gap-2">
              {['ALL', 'LOAD', 'TRANSFER_APP', 'TRANSFER_ACH', 'TRANSFER_SEPA', 'TRANSFER_BANK'].map((t) => (
                <button
                  key={t}
                  onClick={() => setTypeFilter(t)}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
                  style={filterBtnStyle(typeFilter === t)}
                >
                  {t === 'ALL' ? 'All' : TRANSACTION_TYPE_LABELS[t] || t}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Transactions list */}
      <div
        className="rounded-2xl overflow-hidden"
        style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
      >
        <div className="p-5 pb-4 flex items-center justify-between">
          <h3 className="font-semibold text-white">{filtered.length} transactions</h3>
        </div>

        {loading ? (
          <div className="px-5 pb-5 space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-20 rounded-xl shimmer" />
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="p-10 text-center">
            <History className="w-10 h-10 text-gray-600 mx-auto mb-3" />
            <p className="text-gray-500">No transactions found</p>
          </div>
        ) : (
          <div className="px-5 pb-5 space-y-2">
            {filtered.map((tx) => {
              const style = STATUS_STYLES[tx.status] || STATUS_STYLES.PENDING
              return (
                <div
                  key={tx.id}
                  className="p-4 rounded-xl transition-colors"
                  style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.06)' }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                        style={{ background: tx.type === 'LOAD' ? 'rgba(16,185,129,0.1)' : 'rgba(99,102,241,0.1)' }}
                      >
                        {tx.type === 'LOAD' ? (
                          <TrendingUp className="w-5 h-5 text-emerald-400" />
                        ) : (
                          <TrendingDown className="w-5 h-5 text-indigo-400" />
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-white">
                          {TRANSACTION_TYPE_LABELS[tx.type] || tx.type}
                        </p>
                        <p className="text-xs text-gray-500 mt-0.5">
                          {tx.description || (tx.recipientEmail ? `To: ${tx.recipientEmail}` : tx.bankName ? `Bank: ${tx.bankName}` : '')}
                        </p>
                        <p className="text-xs text-gray-600 mt-0.5">{formatDate(tx.createdAt)}</p>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end gap-1.5">
                      <p className="text-sm font-bold" style={{ color: tx.type === 'LOAD' ? '#34d399' : '#f87171' }}>
                        {tx.type === 'LOAD' ? '+' : '-'}{formatCurrency(tx.amountUSD)}
                      </p>
                      {tx.currency !== 'USD' && (
                        <p className="text-xs text-gray-500">
                          {CURRENCY_FLAGS[tx.currency]} {tx.amount.toFixed(2)} {tx.currency}
                        </p>
                      )}
                      <div
                        className="flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium"
                        style={{ background: style.bg, border: `1px solid ${style.border}`, color: style.text }}
                      >
                        {getStatusIcon(tx.status)}
                        {tx.status}
                      </div>
                      {tx.fee > 0 && (
                        <p className="text-xs text-gray-600">Fee: {formatCurrency(tx.fee)}</p>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

'use client'

import { useState, useEffect } from 'react'
import { Header } from '@/components/layout/Header'
import { Send, Loader2, CheckCircle, AlertCircle, Info } from 'lucide-react'
import { formatCurrency } from '@/lib/utils'

export default function SendPage() {
  const [recipientEmail, setRecipientEmail] = useState('')
  const [amount, setAmount] = useState('')
  const [description, setDescription] = useState('')
  const [balance, setBalance] = useState<number | null>(null)
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const [error, setError] = useState('')

  useEffect(() => {
    fetch('/api/wallet/balance')
      .then((r) => r.json())
      .then((d) => setBalance(d.balance))
      .catch(console.error)
  }, [])

  const amountNum = parseFloat(amount) || 0
  const fee = amountNum * 0.005
  const total = amountNum + fee

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError('')
    setSuccess(false)

    try {
      const res = await fetch('/api/wallet/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recipientEmail, amount: amountNum, description }),
      })

      const data = await res.json()

      if (!res.ok) {
        setError(data.error || 'Transfer failed')
      } else {
        setSuccess(true)
        setRecipientEmail('')
        setAmount('')
        setDescription('')
        // Refresh balance
        fetch('/api/wallet/balance').then((r) => r.json()).then((d) => setBalance(d.balance))
      }
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-6 space-y-6">
      <Header title="Send Money" subtitle="Transfer USD to another Global66 user" />

      <div className="max-w-xl mx-auto">
        {/* Balance info */}
        <div
          className="rounded-2xl p-4 mb-6 flex items-center justify-between"
          style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.2)' }}
        >
          <div className="flex items-center gap-2">
            <Info className="w-4 h-4 text-indigo-400" />
            <span className="text-sm text-gray-300">Available balance</span>
          </div>
          <span className="font-bold text-indigo-300">
            {balance !== null ? formatCurrency(balance) : '...'}
          </span>
        </div>

        <div
          className="rounded-2xl p-6"
          style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
        >
          <div className="flex items-center gap-3 mb-6">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: 'rgba(99,102,241,0.1)', border: '1px solid rgba(99,102,241,0.2)' }}
            >
              <Send className="w-5 h-5 text-indigo-400" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Send to User</h2>
              <p className="text-sm text-gray-400">Transfer to another Global66 account</p>
            </div>
          </div>

          {success && (
            <div
              className="flex items-center gap-3 p-4 rounded-xl mb-5"
              style={{ background: 'rgba(16,185,129,0.1)', border: '1px solid rgba(16,185,129,0.2)' }}
            >
              <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0" />
              <div>
                <p className="text-sm font-medium text-emerald-400">Transfer submitted!</p>
                <p className="text-xs text-emerald-400/70 mt-0.5">Your transfer is pending admin approval.</p>
              </div>
            </div>
          )}

          {error && (
            <div
              className="flex items-center gap-3 p-4 rounded-xl mb-5"
              style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.2)' }}
            >
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
              <p className="text-sm text-red-400">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm text-gray-400 mb-2">Recipient Email</label>
              <input
                type="email"
                value={recipientEmail}
                onChange={(e) => setRecipientEmail(e.target.value)}
                placeholder="recipient@example.com"
                required
                className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
              />
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Amount (USD)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-semibold">$</span>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  min="0.01"
                  step="0.01"
                  required
                  className="w-full pl-8 pr-4 py-3 rounded-xl text-white text-xl font-semibold placeholder-gray-700 outline-none transition-all duration-200"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                  onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                  onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-400 mb-2">Note (optional)</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="What is this for?"
                className="w-full px-4 py-3 rounded-xl text-white placeholder-gray-600 outline-none transition-all duration-200"
                style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)' }}
                onFocus={(e) => { e.target.style.borderColor = 'rgba(99,102,241,0.5)' }}
                onBlur={(e) => { e.target.style.borderColor = 'rgba(255,255,255,0.1)' }}
              />
            </div>

            {amountNum > 0 && (
              <div
                className="rounded-xl p-4 space-y-2"
                style={{ background: 'rgba(99,102,241,0.08)', border: '1px solid rgba(99,102,241,0.15)' }}
              >
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Amount</span>
                  <span className="text-white">{formatCurrency(amountNum)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Fee (0.5%)</span>
                  <span className="text-amber-400">-{formatCurrency(fee)}</span>
                </div>
                <div className="border-t pt-2 mt-2 flex justify-between" style={{ borderColor: 'rgba(255,255,255,0.1)' }}>
                  <span className="text-sm font-semibold text-white">Total deducted</span>
                  <span className="text-red-400 font-bold">{formatCurrency(total)}</span>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading || !amount || amountNum <= 0}
              className="w-full py-3 rounded-xl font-semibold text-white flex items-center justify-center gap-2 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              style={{ background: 'linear-gradient(135deg, #6366f1, #8b5cf6)' }}
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
              {loading ? 'Sending...' : 'Send Money'}
            </button>
          </form>
        </div>
      </div>
    </div>
  )
}

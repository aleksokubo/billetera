import { type ClassValue, clsx } from 'clsx'

export function cn(...inputs: ClassValue[]) {
  return inputs.filter(Boolean).join(' ')
}

export function formatDate(date: Date | string): string {
  return new Date(date).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function formatCurrency(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

export function truncateEmail(email: string, maxLength: number = 20): string {
  if (email.length <= maxLength) return email
  const [local, domain] = email.split('@')
  if (local.length > 10) {
    return `${local.slice(0, 8)}...@${domain}`
  }
  return email
}

export const CURRENCY_FLAGS: Record<string, string> = {
  USD: '🇺🇸',
  ARS: '🇦🇷',
  EUR: '🇪🇺',
  GBP: '🇬🇧',
  CLP: '🇨🇱',
  PEN: '🇵🇪',
}

export const CURRENCY_NAMES: Record<string, string> = {
  USD: 'US Dollar',
  ARS: 'Argentine Peso',
  EUR: 'Euro',
  GBP: 'British Pound',
  CLP: 'Chilean Peso',
  PEN: 'Peruvian Sol',
}

export const TRANSACTION_TYPE_LABELS: Record<string, string> = {
  LOAD: 'Load Balance',
  TRANSFER_APP: 'Send to User',
  TRANSFER_ACH: 'ACH Transfer',
  TRANSFER_SEPA: 'SEPA Transfer',
  TRANSFER_BANK: 'Bank Wire',
}

export const STATUS_COLORS: Record<string, string> = {
  PENDING: 'text-amber-400 bg-amber-400/10',
  APPROVED: 'text-emerald-400 bg-emerald-400/10',
  REJECTED: 'text-red-400 bg-red-400/10',
}

import { prisma } from './prisma'

const SUPPORTED_CURRENCIES = ['ARS', 'EUR', 'GBP', 'CLP', 'PEN']

export async function fetchExchangeRates(): Promise<Record<string, number>> {
  const rates: Record<string, number> = {}

  try {
    // Try open.er-api.com as primary source
    const response = await fetch('https://open.er-api.com/v6/latest/USD', {
      next: { revalidate: 300 },
    })

    if (response.ok) {
      const data = await response.json()
      if (data.rates) {
        for (const currency of SUPPORTED_CURRENCIES) {
          if (data.rates[currency]) {
            // rate = how many units of currency per 1 USD
            rates[currency] = data.rates[currency]
          }
        }
        return rates
      }
    }
  } catch (error) {
    console.error('Error fetching from open.er-api.com:', error)
  }

  // Fallback: Try Binance API for some pairs
  try {
    const binancePairs: Record<string, string> = {
      EUR: 'EURUSDT',
      GBP: 'GBPUSDT',
    }

    for (const [currency, symbol] of Object.entries(binancePairs)) {
      try {
        const res = await fetch(
          `https://api.binance.com/api/v3/ticker/price?symbol=${symbol}`
        )
        if (res.ok) {
          const data = await res.json()
          // For EURUSDT: 1 EUR = X USD, so 1 USD = 1/X EUR
          rates[currency] = 1 / parseFloat(data.price)
        }
      } catch (e) {
        console.error(`Error fetching ${symbol} from Binance:`, e)
      }
    }
  } catch (error) {
    console.error('Error fetching from Binance:', error)
  }

  // Use defaults if still missing
  const defaults: Record<string, number> = {
    ARS: 1000,
    EUR: 0.92,
    GBP: 0.79,
    CLP: 950,
    PEN: 3.75,
  }

  for (const currency of SUPPORTED_CURRENCIES) {
    if (!rates[currency]) {
      rates[currency] = defaults[currency]
    }
  }

  return rates
}

export async function updateExchangeRatesInDB(): Promise<void> {
  try {
    const rates = await fetchExchangeRates()

    for (const [currency, rate] of Object.entries(rates)) {
      await prisma.exchangeRate.upsert({
        where: { currency },
        update: {
          rate,
          source: 'api',
          updatedAt: new Date(),
        },
        create: {
          currency,
          rate,
          source: 'api',
        },
      })
    }
  } catch (error) {
    console.error('Error updating exchange rates in DB:', error)
  }
}

export async function getExchangeRatesFromDB(): Promise<Record<string, number>> {
  const rates = await prisma.exchangeRate.findMany()
  const ratesMap: Record<string, number> = {}

  for (const rate of rates) {
    ratesMap[rate.currency] = rate.rate
  }

  return ratesMap
}

export function convertToUSD(amount: number, currency: string, rate: number): number {
  // rate = units of currency per 1 USD
  // so to convert currency to USD: amount / rate
  if (currency === 'USD') return amount
  return amount / rate
}

export function formatCurrency(amount: number, currency: string = 'USD'): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}
